Karsak Stundenzettel MITARBEITER FX68

Mitarbeiter-App mit Supabase-Synchronisierung und Chef-Rückmeldung.

Statusfarben:
- Gelb = gesendet / wartet auf Chef
- Grün = genehmigt
- Orange = vom Chef geändert
- Rot = vom Chef abgelehnt

Der Monatskalender zeigt nur die eigenen Stunden und den Prüfstatus.

Karsak Stundenzettel MITARBEITER FX70 – Senden + Empfangen mit eindeutiger Supabase-ID und sichtbarem Chefstatus.

FX71: Expliziter Synchronisieren-Button + sichtbarer Empfang/Fehlerstatus.

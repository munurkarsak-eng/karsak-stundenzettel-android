package de.karsak.stundenzettel.mitarbeiter
import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.print.PrintAttributes
import android.print.PrintManager
import java.io.File
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.util.Base64
import java.net.HttpURLConnection
import java.net.URL
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.UUID

import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.json.JSONArray
import java.util.Locale
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var pendingWebPermission: PermissionRequest? = null
    private var pendingGeoOrigin: String? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null
    private var pendingNativeListen = false
    private var pendingConversationStart = false
    private var conversationRecorder: MediaRecorder? = null
    private var conversationFile: File? = null
    private var conversationStartedAt: Long = 0L
    private var conversationPlayer: MediaPlayer? = null

    private var textToSpeech: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private var pendingSpeech: SpeechRequest? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var listenFallback: Runnable? = null
    private var startListenRunnable: Runnable? = null
    @Volatile private var nativeListening = false
    private var nativeListenRetries = 0

    data class SpeechRequest(
        val message: String,
        val volumePercent: Int,
        val gender: String,
        val listenAfter: Boolean,
        val voiceName: String = "",
        val ratePercent: Int = 103,
        val pitchPercent: Int = 100
    )

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val audioGranted = result[Manifest.permission.RECORD_AUDIO] == true ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (pendingWebPermission != null) {
            if (audioGranted) pendingWebPermission?.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
            else pendingWebPermission?.deny()
            pendingWebPermission = null
        }
        if (pendingNativeListen) {
            pendingNativeListen = false
            if (audioGranted) requestNativeListening(250L, resetRetries = true)
            else sendSpeechResult(null, "Mikrofonzugriff wurde nicht erlaubt.")
        }
        if (pendingConversationStart) {
            pendingConversationStart = false
            if (audioGranted) startConversationRecordingNative()
            else runOnUiThread {
                webView.evaluateJavascript(
                    "window.fx25RecordingError && window.fx25RecordingError('Mikrofonzugriff wurde nicht erlaubt.')",
                    null
                )
            }
        }

        val locationGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (pendingGeoCallback != null) {
            pendingGeoCallback?.invoke(pendingGeoOrigin, locationGranted, false)
            pendingGeoOrigin = null
            pendingGeoCallback = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
        }

        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val tts = textToSpeech ?: return@TextToSpeech
                val result = tts.setLanguage(Locale.GERMANY)
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
                tts.setSpeechRate(1.03f)
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) {
                        if (utteranceId?.startsWith("listen-") == true) runOnUiThread {
                            listenFallback?.let(mainHandler::removeCallbacks)
                            listenFallback = null
                            requestNativeListening(420L, resetRetries = true)
                        }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        if (utteranceId?.startsWith("listen-") == true) runOnUiThread {
                            listenFallback?.let(mainHandler::removeCallbacks)
                            listenFallback = null
                            requestNativeListening(500L, resetRetries = true)
                        }
                    }
                })
                pendingSpeech?.let {
                    pendingSpeech = null
                    speakNative(it.message, it.volumePercent, it.gender, it.listenAfter, it.voiceName, it.ratePercent, it.pitchPercent)
                }
            } else {
                ttsReady = false
                Toast.makeText(this, "Android-Sprachausgabe konnte nicht gestartet werden.", Toast.LENGTH_LONG).show()
            }
        }

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.setGeolocationEnabled(true)
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.userAgentString = webView.settings.userAgentString + " KarsakStundenzettelAndroid/FX68"

        val bridge = AndroidBridge(this)
        webView.addJavascriptInterface(bridge, "Android")
        webView.addJavascriptInterface(bridge, "KarsakAndroid")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return if (uri.scheme == "file") false else {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    true
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
                        if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                        } else {
                            pendingWebPermission = request
                            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                        }
                    } else request.deny()
                }
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                val fine = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                val coarse = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (fine || coarse) callback?.invoke(origin, true, false)
                else {
                    pendingGeoOrigin = origin
                    pendingGeoCallback = callback
                    permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                }
            }
        }

        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)
    }

    private fun speakNative(message: String, volumePercent: Int, gender: String, listenAfter: Boolean = false, voiceName: String = "", ratePercent: Int = 103, pitchPercent: Int = 100) {
        val safeMessage = message.trim()
        if (safeMessage.isEmpty()) {
            if (listenAfter) requestNativeListening(250L, resetRetries = true)
            return
        }
        if (!ttsReady) {
            pendingSpeech = SpeechRequest(safeMessage, volumePercent, gender, listenAfter, voiceName, ratePercent, pitchPercent)
            return
        }
        val tts = textToSpeech ?: return
        val volume = (volumePercent.coerceIn(0, 100) / 100f).coerceAtLeast(0.01f)
        val germanVoices = tts.voices?.filter { it.locale?.language == Locale.GERMAN.language }.orEmpty()
        val genderHints = if (gender.equals("male", true)) {
            listOf("male", "mann", "hans", "markus", "stefan", "conrad", "bernd", "klaus", "daniel")
        } else {
            listOf("female", "frau", "anna", "katja", "petra", "amelie", "vicki", "sandy", "helena", "marlene", "hedda")
        }
        val selectedVoice = germanVoices.firstOrNull { it.name == voiceName }
        val bestVoice = selectedVoice ?: germanVoices
            .sortedWith(compareByDescending<android.speech.tts.Voice> { it.quality }.thenBy { it.isNetworkConnectionRequired })
            .firstOrNull { v -> genderHints.any { h -> v.name.lowercase(Locale.GERMANY).contains(h) } }
            ?: germanVoices.sortedWith(compareByDescending<android.speech.tts.Voice> { it.quality }.thenBy { it.isNetworkConnectionRequired }).firstOrNull()
        if (bestVoice != null) tts.voice = bestVoice
        tts.setPitch((pitchPercent.coerceIn(70, 130) / 100f))
        tts.setSpeechRate((ratePercent.coerceIn(70, 140) / 100f))
        val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume) }
        val prefix = if (listenAfter) "listen" else "speak"
        val utteranceId = "$prefix-${System.currentTimeMillis()}"
        listenFallback?.let(mainHandler::removeCallbacks)
        listenFallback = null
        tts.stop()
        tts.speak(safeMessage, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        if (listenAfter) {
            val estimatedMs = (safeMessage.length * 70L).coerceIn(1500L, 5200L)
            listenFallback = Runnable {
                listenFallback = null
                if (!tts.isSpeaking) requestNativeListening(200L, resetRetries = true) else requestNativeListening(900L, resetRetries = true)
            }.also { mainHandler.postDelayed(it, estimatedMs + 700L) }
        }
    }

    private fun requestNativeListening(delayMs: Long = 0L, resetRetries: Boolean = false) {
        if (resetRetries) nativeListenRetries = 0
        startListenRunnable?.let(mainHandler::removeCallbacks)
        startListenRunnable = Runnable {
            startListenRunnable = null
            startNativeListening()
        }.also { mainHandler.postDelayed(it, delayMs) }
    }

    private fun disposeSpeechRecognizer() {
        val old = speechRecognizer
        speechRecognizer = null
        nativeListening = false
        runCatching { old?.cancel() }
        runCatching { old?.destroy() }
    }

    private fun retryNativeListening(message: String? = null) {
        if (nativeListenRetries < 4) {
            nativeListenRetries++
            message?.let { sendAssistantStatus(it) }
            disposeSpeechRecognizer()
            requestNativeListening(420L + nativeListenRetries * 120L)
        } else {
            nativeListenRetries = 0
            disposeSpeechRecognizer()
            sendSpeechResult(null, message ?: "Spracherkennung konnte nicht gestartet werden. Ich versuche es erneut.")
        }
    }

    private fun sendAssistantStatus(message: String) {
        runOnUiThread {
            val js = "window.karsakNativeSpeechStatus && window.karsakNativeSpeechStatus(" + JSONObject.quote(message) + ");"
            webView.evaluateJavascript(js, null)
        }
    }

    private fun startConversationRecordingNative() {
        runOnUiThread {
            try {
                if (conversationRecorder != null) return@runOnUiThread
                val dir = File(filesDir, "gespraeche")
                if (!dir.exists()) dir.mkdirs()
                val file = File(dir, "gespraech_${System.currentTimeMillis()}.m4a")

                val recorder = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                    MediaRecorder(this)
                } else {
                    @Suppress("DEPRECATION")
                    MediaRecorder()
                }

                recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
                recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                recorder.setAudioEncodingBitRate(96000)
                recorder.setAudioSamplingRate(44100)
                recorder.setOutputFile(file.absolutePath)
                recorder.prepare()
                recorder.start()

                conversationRecorder = recorder
                conversationFile = file
                conversationStartedAt = System.currentTimeMillis()
                webView.evaluateJavascript(
                    "window.fx25RecordingStarted && window.fx25RecordingStarted()",
                    null
                )
            } catch (e: Exception) {
                try { conversationRecorder?.release() } catch (_: Exception) {}
                conversationRecorder = null
                conversationFile = null
                val msg = JSONObject.quote("Aufnahme konnte nicht gestartet werden: ${e.message ?: "unbekannter Fehler"}")
                webView.evaluateJavascript(
                    "window.fx25RecordingError && window.fx25RecordingError($msg)",
                    null
                )
            }
        }
    }

    private fun stopConversationRecordingNative() {
        runOnUiThread {
            val recorder = conversationRecorder
            val file = conversationFile
            if (recorder == null || file == null) {
                webView.evaluateJavascript(
                    "window.fx25RecordingError && window.fx25RecordingError('Keine laufende Aufnahme.')",
                    null
                )
                return@runOnUiThread
            }
            try {
                recorder.stop()
            } catch (_: Exception) {
                try { file.delete() } catch (_: Exception) {}
            } finally {
                try { recorder.reset() } catch (_: Exception) {}
                try { recorder.release() } catch (_: Exception) {}
                conversationRecorder = null
            }

            val seconds = ((System.currentTimeMillis() - conversationStartedAt) / 1000L).coerceAtLeast(1L)
            val p = JSONObject.quote(file.absolutePath)
            webView.evaluateJavascript(
                "window.fx25RecordingStopped && window.fx25RecordingStopped($p, $seconds)",
                null
            )
            conversationFile = null
            conversationStartedAt = 0L
        }
    }

    private fun playConversationRecordingNative(path: String) {
        runOnUiThread {
            try {
                conversationPlayer?.stop()
                conversationPlayer?.release()
            } catch (_: Exception) {}
            conversationPlayer = null

            try {
                val file = File(path)
                if (!file.exists()) {
                    Toast.makeText(this, "Aufnahme wurde nicht gefunden.", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                val player = MediaPlayer()
                player.setDataSource(file.absolutePath)
                player.setOnCompletionListener {
                    try { it.release() } catch (_: Exception) {}
                    if (conversationPlayer === it) conversationPlayer = null
                }
                player.prepare()
                player.start()
                conversationPlayer = player
            } catch (e: Exception) {
                Toast.makeText(this, "Aufnahme konnte nicht abgespielt werden.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun deleteConversationRecordingNative(path: String) {
        runOnUiThread {
            try {
                val file = File(path)
                if (file.exists()) file.delete()
            } catch (_: Exception) {}
        }
    }

    private val supabaseUrl = "https://lxwcbyywppcfzvyyykse.supabase.co"
    private val supabasePublishableKey = "sb_publishable_Ec8huFyO5fa9kKF5kwvb2g_NWUeaO3j"

    private fun supabaseConfigured(): Boolean =
        supabaseUrl.startsWith("https://") && supabasePublishableKey.startsWith("sb_publishable_")

    private fun jsCall(functionName: String, vararg args: Any?) {
        val encoded = args.joinToString(",") { value ->
            when (value) {
                null -> "null"
                is Boolean, is Number -> value.toString()
                else -> JSONObject.quote(value.toString())
            }
        }
        runOnUiThread {
            webView.evaluateJavascript("window.$functionName && window.$functionName($encoded)", null)
        }
    }

    private data class SupabaseSession(val accessToken: String, val refreshToken: String, val uid: String, val expiresAtMs: Long)

    private fun readSupabaseSession(): SupabaseSession? {
        val p = getSharedPreferences("supabase_fx64", Context.MODE_PRIVATE)
        val access = p.getString("access_token", null).orEmpty()
        val refresh = p.getString("refresh_token", null).orEmpty()
        val uid = p.getString("uid", null).orEmpty()
        val exp = p.getLong("expires_at_ms", 0L)
        return if (access.isBlank() || uid.isBlank()) null else SupabaseSession(access, refresh, uid, exp)
    }

    private fun saveSupabaseSession(json: JSONObject): SupabaseSession? {
        val access = json.optString("access_token")
        val refresh = json.optString("refresh_token")
        val uid = json.optJSONObject("user")?.optString("id").orEmpty()
        val expiresIn = json.optLong("expires_in", 3600L)
        if (access.isBlank() || uid.isBlank()) return null
        val exp = System.currentTimeMillis() + (expiresIn * 1000L) - 60_000L
        getSharedPreferences("supabase_fx64", Context.MODE_PRIVATE).edit()
            .putString("access_token", access)
            .putString("refresh_token", refresh)
            .putString("uid", uid)
            .putLong("expires_at_ms", exp)
            .apply()
        return SupabaseSession(access, refresh, uid, exp)
    }

    private fun httpJson(method: String, endpoint: String, body: JSONObject? = null, bearer: String? = null, prefer: String? = null): Pair<Int, String> {
        val c = (URL(endpoint).openConnection() as HttpURLConnection)
        c.requestMethod = method
        c.connectTimeout = 12000
        c.readTimeout = 12000
        c.setRequestProperty("apikey", supabasePublishableKey)
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Accept", "application/json")
        if (!bearer.isNullOrBlank()) c.setRequestProperty("Authorization", "Bearer $bearer")
        if (!prefer.isNullOrBlank()) c.setRequestProperty("Prefer", prefer)
        if (body != null) {
            c.doOutput = true
            OutputStreamWriter(c.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        return code to text
    }

    private fun ensureSupabaseSession(onReady: (SupabaseSession) -> Unit, onError: (String) -> Unit) {
        if (!supabaseConfigured()) {
            onError("Supabase ist nicht eingerichtet.")
            return
        }
        Thread {
            try {
                val old = readSupabaseSession()
                if (old != null && old.expiresAtMs > System.currentTimeMillis()) {
                    onReady(old)
                    return@Thread
                }
                if (old != null && old.refreshToken.isNotBlank()) {
                    val (rc, rb) = httpJson(
                        "POST",
                        "$supabaseUrl/auth/v1/token?grant_type=refresh_token",
                        JSONObject().put("refresh_token", old.refreshToken)
                    )
                    if (rc in 200..299) {
                        saveSupabaseSession(JSONObject(rb))?.let { onReady(it); return@Thread }
                    }
                }
                // Anonyme Supabase-Anmeldung. In Supabase muss "Anonyme Anmeldungen" aktiviert sein.
                val (code, body) = httpJson("POST", "$supabaseUrl/auth/v1/signup", JSONObject())
                if (code !in 200..299) {
                    val msg = runCatching {
                        val j = JSONObject(body)
                        j.optString("msg").ifBlank { j.optString("message").ifBlank { j.optString("error_description") } }
                    }.getOrNull().orEmpty()
                    onError(if (msg.isNotBlank()) "Supabase-Anmeldung: $msg" else "Supabase-Anmeldung fehlgeschlagen (HTTP $code).")
                    return@Thread
                }
                val session = saveSupabaseSession(JSONObject(body))
                if (session == null) onError("Supabase-Anmeldung ohne Sitzung oder Benutzer-ID.") else onReady(session)
            } catch (e: Exception) {
                onError("Supabase-Verbindung fehlgeschlagen: ${e.message ?: "unbekannter Fehler"}")
            }
        }.start()
    }


    private fun loadConstructionSitesNative() {
        ensureSupabaseSession(
            onReady = { session ->
                Thread {
                    try {
                        val endpoint = "$supabaseUrl/rest/v1/construction_sites?select=site_key,name,active&active=eq.true&order=name.asc"
                        val (code, body) = httpJson("GET", endpoint, bearer = session.accessToken)
                        if (code in 200..299) {
                            jsCall("fx73ConstructionSitesLoaded", body)
                        } else {
                            val detail = runCatching {
                                val j = JSONObject(body)
                                j.optString("message").ifBlank { j.optString("details").ifBlank { j.optString("hint") } }
                            }.getOrNull().orEmpty()
                            jsCall("fx73ConstructionSitesError", if (detail.isNotBlank()) detail else "Baustellen konnten nicht geladen werden (HTTP $code).")
                        }
                    } catch (e: Exception) {
                        jsCall("fx73ConstructionSitesError", "Baustellen konnten nicht geladen werden: ${e.message ?: "unbekannter Fehler"}")
                    }
                }.start()
            },
            onError = { error -> jsCall("fx73ConstructionSitesError", error) }
        )
    }

    private fun syncHourEntryNative(json: String) {
        val o = try { JSONObject(json) } catch (_: Exception) {
            jsCall("fx62SyncError", "", "Eintrag konnte nicht gelesen werden.")
            return
        }
        val clientEntryId = o.optString("id").ifBlank { "entry_${System.currentTimeMillis()}" }
        ensureSupabaseSession(
            onReady = { session ->
                Thread {
                    try {
                        val row = JSONObject()
                            .put("user_id", session.uid)
                            .put("datum", o.optString("date"))
                            .put("startzeit", o.optString("start"))
                            .put("endzeit", o.optString("end"))
                            .put("baustelle", o.optString("siteName"))
                            .put("pause", o.optInt("pause", 0))
                            .put("employee_name", o.optString("employeeName"))
                            .put("status", "pending")
                        // employee_id ist in Supabase UUID. Die lokale FX62-ID ist Text (z. B. employee_...).
                        // Deshalb wird employee_id hier bewusst nicht gesendet.
                        val (code, body) = httpJson(
                            "POST",
                            "$supabaseUrl/rest/v1/work_entries",
                            row,
                            session.accessToken,
                            "return=representation"
                        )
                        if (code in 200..299) {
                            val cloudRowId = runCatching {
                                val trimmed = body.trim()
                                if (trimmed.startsWith("[")) JSONArray(trimmed).optJSONObject(0)?.optString("id").orEmpty()
                                else JSONObject(trimmed).optString("id")
                            }.getOrDefault("")
                            jsCall("fx62SyncSuccess", clientEntryId, cloudRowId)
                            // Direkt nach dem Senden den aktuellen Chef-Status zurückholen.
                            loadMyReviewStatusNative(o.optString("employeeName"), listOfNotNull(cloudRowId.takeIf { it.isNotBlank() }))
                        } else {
                            val detail = runCatching {
                                val j = JSONObject(body)
                                j.optString("message").ifBlank { j.optString("details").ifBlank { j.optString("hint") } }
                            }.getOrNull().orEmpty()
                            jsCall("fx62SyncError", clientEntryId, if (detail.isNotBlank()) detail else "Supabase-Übertragung fehlgeschlagen (HTTP $code).")
                        }
                    } catch (e: Exception) {
                        jsCall("fx62SyncError", clientEntryId, "Supabase-Übertragung fehlgeschlagen: ${e.message ?: "unbekannter Fehler"}")
                    }
                }.start()
            },
            onError = { error -> jsCall("fx62SyncError", clientEntryId, error) }
        )
    }

    private fun loadMyReviewStatusNative(employeeName: String = "", cloudIds: List<String> = emptyList()) {
        ensureSupabaseSession(
            onReady = { session ->
                Thread {
                    try {
                        val select = "id,user_id,employee_name,datum,startzeit,endzeit,baustelle,status,chef_start,chef_end,hourly_rate,review_reason"
                        val merged = LinkedHashMap<String, JSONObject>()

                        fun addRows(body: String) {
                            val arr = JSONArray(body)
                            for (i in 0 until arr.length()) {
                                val row = arr.optJSONObject(i) ?: continue
                                val id = row.optString("id")
                                if (id.isNotBlank()) merged[id] = row
                            }
                        }

                        var anySuccess = false
                        var lastError = ""

                        val uid = java.net.URLEncoder.encode(session.uid, "UTF-8")
                        val ownEndpoint = "$supabaseUrl/rest/v1/work_entries" +
                            "?select=$select&user_id=eq.$uid&order=datum.asc"
                        val (ownCode, ownBody) = httpJson("GET", ownEndpoint, bearer = session.accessToken)
                        if (ownCode in 200..299) {
                            anySuccess = true
                            addRows(ownBody)
                        } else {
                            lastError = ownBody
                        }

                        val cleanIds = cloudIds.map { it.trim() }.filter { it.matches(Regex("^[A-Za-z0-9_-]+$")) }.distinct().take(200)
                        if (cleanIds.isNotEmpty()) {
                            val inFilter = cleanIds.joinToString(",")
                            val idEndpoint = "$supabaseUrl/rest/v1/work_entries" +
                                "?select=$select&id=in.($inFilter)&order=datum.asc"
                            val (idCode, idBody) = httpJson("GET", idEndpoint, bearer = session.accessToken)
                            if (idCode in 200..299) {
                                anySuccess = true
                                addRows(idBody)
                            } else if (lastError.isBlank()) {
                                lastError = idBody
                            }
                        }

                        val cleanName = employeeName.trim()
                        if (cleanName.isNotBlank()) {
                            val encodedName = java.net.URLEncoder.encode(cleanName, "UTF-8").replace("+", "%20")
                            val nameEndpoint = "$supabaseUrl/rest/v1/work_entries" +
                                "?select=$select&employee_name=eq.$encodedName&order=datum.asc"
                            val (nameCode, nameBody) = httpJson("GET", nameEndpoint, bearer = session.accessToken)
                            if (nameCode in 200..299) {
                                anySuccess = true
                                addRows(nameBody)
                            } else if (lastError.isBlank()) {
                                lastError = nameBody
                            }
                        }

                        if (anySuccess) {
                            val out = JSONArray()
                            merged.values.forEach { out.put(it) }
                            jsCall("fx68ReviewLoaded", out.toString())
                        } else {
                            val detail = runCatching {
                                val j = JSONObject(lastError)
                                j.optString("message").ifBlank { j.optString("details").ifBlank { j.optString("hint") } }
                            }.getOrNull().orEmpty()
                            jsCall("fx68ReviewError", if (detail.isNotBlank()) detail else "Chef-Status konnte nicht geladen werden.")
                        }
                    } catch (e: Exception) {
                        jsCall("fx68ReviewError", "Status konnte nicht geladen werden: ${e.message ?: "unbekannter Fehler"}")
                    }
                }.start()
            },
            onError = { error -> jsCall("fx68ReviewError", error) }
        )
    }


    private fun loadEmployeePaymentsNative(employeeName: String) {
        val cleanName = employeeName.trim()
        if (cleanName.isBlank()) {
            jsCall("fx72PaymentsLoaded", "[]")
            return
        }
        ensureSupabaseSession(
            onReady = { session ->
                Thread {
                    try {
                        val encodedName = java.net.URLEncoder.encode(cleanName, "UTF-8").replace("+", "%20")
                        val select = "id,employee_name,payment_date,payment_type,amount,note,settlement_month"
                        val endpoint = "$supabaseUrl/rest/v1/employee_payments?select=$select&employee_name=eq.$encodedName&order=payment_date.asc"
                        val (code, body) = httpJson("GET", endpoint, bearer = session.accessToken)
                        if (code in 200..299) {
                            jsCall("fx72PaymentsLoaded", body)
                        } else {
                            val detail = runCatching {
                                val j = JSONObject(body)
                                j.optString("message").ifBlank { j.optString("details").ifBlank { j.optString("hint") } }
                            }.getOrNull().orEmpty()
                            jsCall("fx72PaymentsError", if (detail.isNotBlank()) detail else "Zahlungen konnten nicht geladen werden (HTTP $code).")
                        }
                    } catch (e: Exception) {
                        jsCall("fx72PaymentsError", "Zahlungen konnten nicht geladen werden: ${e.message ?: "unbekannter Fehler"}")
                    }
                }.start()
            },
            onError = { error -> jsCall("fx72PaymentsError", error) }
        )
    }

    private fun startNativeListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingNativeListen = true
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendSpeechResult(null, "Spracherkennung ist auf diesem Gerät nicht verfügbar.")
            return
        }

        // Nie in die eigene Sprachausgabe hinein zuhören. Nach dem letzten Wort kurz warten.
        if (textToSpeech?.isSpeaking == true) {
            requestNativeListening(300L)
            return
        }
        if (nativeListening) return

        disposeSpeechRecognizer()
        val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer = recognizer
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                if (speechRecognizer !== recognizer) return
                nativeListening = true
                nativeListenRetries = 0
                sendAssistantStatus("Jetzt sprechen …")
            }
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onError(error: Int) {
                if (speechRecognizer !== recognizer) return
                nativeListening = false
                when (error) {
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                        disposeSpeechRecognizer()
                        sendSpeechResult(null, "Mikrofonzugriff wurde nicht erlaubt.")
                    }
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                    SpeechRecognizer.ERROR_CLIENT -> retryNativeListening("Mikrofon wird neu gestartet …")
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> retryNativeListening("Ich habe nichts verstanden. Ich höre noch einmal zu …")
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                    SpeechRecognizer.ERROR_SERVER -> retryNativeListening("Spracherkennung wird erneut gestartet …")
                    else -> retryNativeListening("Mikrofon wird erneut gestartet …")
                }
            }
            override fun onResults(results: Bundle?) {
                if (speechRecognizer !== recognizer) return
                nativeListening = false
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                disposeSpeechRecognizer()
                nativeListenRetries = 0
                if (text.isNullOrBlank()) {
                    requestNativeListening(450L, resetRetries = true)
                } else {
                    sendSpeechResult(text, null)
                }
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1100L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
        }
        nativeListening = true
        try {
            recognizer.startListening(intent)
        } catch (_: Throwable) {
            nativeListening = false
            retryNativeListening("Mikrofon wird neu gestartet …")
        }
    }

    private fun sendSpeechResult(text: String?, error: String?) {
        runOnUiThread {
            val js = "window.karsakNativeSpeechResult && window.karsakNativeSpeechResult(" +
                    (text?.let { JSONObject.quote(it) } ?: "null") + "," +
                    (error?.let { JSONObject.quote(it) } ?: "null") + ");"
            webView.evaluateJavascript(js, null)
        }
    }

    override fun onDestroy() {
        listenFallback?.let(mainHandler::removeCallbacks)
        listenFallback = null
        startListenRunnable?.let(mainHandler::removeCallbacks)
        startListenRunnable = null
        disposeSpeechRecognizer()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    private fun bestLastKnownLocation(): Location? {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return null
        val manager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return runCatching {
            manager.getProviders(true).mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }
                .maxByOrNull { it.time }
        }.getOrNull()
    }

    private fun estimateDriveMinutesForAddress(address: String): Int {
        val origin = bestLastKnownLocation() ?: return -1
        if (address.isBlank()) return -1
        val geocoder = Geocoder(this, Locale.GERMANY)
        val query = if (address.contains(',')) address else {
            val locality = runCatching { geocoder.getFromLocation(origin.latitude, origin.longitude, 1)?.firstOrNull()?.locality }.getOrNull()
            if (!locality.isNullOrBlank()) "$address, $locality" else address
        }
        val destination = runCatching { geocoder.getFromLocationName(query, 1)?.firstOrNull() }.getOrNull() ?: return -1
        val earthKm = 6371.0
        val dLat = Math.toRadians(destination.latitude - origin.latitude)
        val dLon = Math.toRadians(destination.longitude - origin.longitude)
        val a = sin(dLat / 2) * sin(dLat / 2) + cos(Math.toRadians(origin.latitude)) * cos(Math.toRadians(destination.latitude)) * sin(dLon / 2) * sin(dLon / 2)
        val straightKm = earthKm * 2 * asin(sqrt(a.coerceIn(0.0, 1.0)))
        // GPS/Geocoder-Schätzung: Straßennetzfaktor plus typische Stadt-/Landgeschwindigkeit.
        val roadKm = straightKm * if (straightKm < 8.0) 1.28 else 1.18
        val averageKmh = when {
            roadKm < 3.0 -> 28.0
            roadKm < 10.0 -> 38.0
            roadKm < 30.0 -> 52.0
            else -> 68.0
        }
        return ((roadKm / averageKmh) * 60.0 + 1.5).roundToInt().coerceIn(2, 240)
    }


    private val apiPrefs by lazy { getSharedPreferences("karsak_ai_secure", Context.MODE_PRIVATE) }
    private val apiAlias = "karsak_openai_api_key"

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(apiAlias, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                apiAlias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return generator.generateKey()
    }

    private fun saveApiKeySecurely(apiKey: String) {
        val trimmed = apiKey.trim()
        if (trimmed.isEmpty()) {
            apiPrefs.edit().remove("api_key_cipher").remove("api_key_iv").apply()
            return
        }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey())
        val encrypted = cipher.doFinal(trimmed.toByteArray(Charsets.UTF_8))
        apiPrefs.edit()
            .putString("api_key_cipher", Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .putString("api_key_iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .apply()
    }

    private fun loadApiKeySecurely(): String? {
        val cipherText = apiPrefs.getString("api_key_cipher", null) ?: return null
        val ivText = apiPrefs.getString("api_key_iv", null) ?: return null
        return runCatching {
            val encrypted = Base64.decode(cipherText, Base64.NO_WRAP)
            val iv = Base64.decode(ivText, Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(encrypted), Charsets.UTF_8)
        }.getOrNull()
    }

    private fun sendAiResult(text: String?, error: String?, responseId: String?) {
        runOnUiThread {
            val js = "window.karsakAiResult && window.karsakAiResult(" +
                    (text?.let { JSONObject.quote(it) } ?: "null") + "," +
                    (error?.let { JSONObject.quote(it) } ?: "null") + "," +
                    (responseId?.let { JSONObject.quote(it) } ?: "null") + ");"
            webView.evaluateJavascript(js, null)
        }
    }

    private fun requestOpenAi(message: String, previousResponseId: String?, model: String) {
        val apiKey = loadApiKeySecurely()
        if (apiKey.isNullOrBlank()) {
            sendAiResult(null, "Bitte zuerst in Einstellungen den OpenAI-API-Schlüssel hinterlegen.", null)
            return
        }
        Thread {
            var connection: HttpURLConnection? = null
            try {
                val payload = JSONObject().apply {
                    put("model", model.ifBlank { "gpt-5.6-luna" })
                    put("instructions", "Du bist der freundliche KI-Assistent im Karsak Terminplaner. Antworte auf Deutsch, natürlich, knapp und klar. Sprich den Nutzer mit Herr Karsak an, aber nicht in jedem Satz. Wenn eine Aussage unklar ist, frage kurz nach. Erfinde keine Termine oder Fakten.")
                    put("input", message)
                    if (!previousResponseId.isNullOrBlank()) put("previous_response_id", previousResponseId)
                }
                connection = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 60000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer $apiKey")
                }
                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val body = BufferedReader(InputStreamReader(stream)).use { it.readText() }
                if (code !in 200..299) {
                    val detail = runCatching {
                        JSONObject(body).optJSONObject("error")?.optString("message")
                    }.getOrNull().orEmpty()
                    sendAiResult(null, if (detail.isNotBlank()) "OpenAI: $detail" else "OpenAI-Anfrage fehlgeschlagen (HTTP $code).", null)
                    return@Thread
                }
                val json = JSONObject(body)
                val responseId = json.optString("id").ifBlank { null }
                val out = StringBuilder()
                val output = json.optJSONArray("output")
                if (output != null) {
                    for (i in 0 until output.length()) {
                        val item = output.optJSONObject(i) ?: continue
                        val content = item.optJSONArray("content") ?: continue
                        for (j in 0 until content.length()) {
                            val part = content.optJSONObject(j) ?: continue
                            if (part.optString("type") == "output_text") {
                                val t = part.optString("text")
                                if (t.isNotBlank()) {
                                    if (out.isNotEmpty()) out.append(' ')
                                    out.append(t)
                                }
                            }
                        }
                    }
                }
                if (out.isEmpty()) sendAiResult(null, "Die KI hat keine Textantwort geliefert.", responseId)
                else sendAiResult(out.toString().trim(), null, responseId)
            } catch (t: Throwable) {
                sendAiResult(null, "KI-Verbindung fehlgeschlagen: ${t.message ?: "unbekannter Fehler"}", null)
            } finally {
                connection?.disconnect()
            }
        }.start()
    }

    inner class AndroidBridge(private val context: Context) {

        @android.webkit.JavascriptInterface
        fun supabaseReady(): Boolean = supabaseConfigured()

        @android.webkit.JavascriptInterface
        fun syncHourEntry(json: String) {
            syncHourEntryNative(json)
        }

        @android.webkit.JavascriptInterface
        fun loadMyReviewStatus() {
            loadMyReviewStatusNative()
        }

        @android.webkit.JavascriptInterface
        fun loadMyReviewStatusFx69(employeeName: String) {
            loadMyReviewStatusNative(employeeName)
        }

        @android.webkit.JavascriptInterface
        fun loadMyReviewStatusFx70(employeeName: String, cloudIdsJson: String) {
            val ids = runCatching {
                val a = JSONArray(cloudIdsJson)
                (0 until a.length()).mapNotNull { i -> a.optString(i).takeIf { it.isNotBlank() } }
            }.getOrDefault(emptyList())
            loadMyReviewStatusNative(employeeName, ids)
        }





        @android.webkit.JavascriptInterface
        fun loadConstructionSitesFx73() {
            loadConstructionSitesNative()
        }

        @android.webkit.JavascriptInterface
        fun loadEmployeePaymentsFx72(employeeName: String) {
            loadEmployeePaymentsNative(employeeName)
        }

        @android.webkit.JavascriptInterface
        fun startConversationRecording() {
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                startConversationRecordingNative()
            } else {
                pendingConversationStart = true
                permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            }
        }

        @android.webkit.JavascriptInterface
        fun stopConversationRecording() {
            stopConversationRecordingNative()
        }

        @android.webkit.JavascriptInterface
        fun playConversationRecording(path: String) {
            playConversationRecordingNative(path)
        }

        @android.webkit.JavascriptInterface
        fun deleteConversationRecording(path: String) {
            deleteConversationRecordingNative(path)
        }


        @android.webkit.JavascriptInterface
        fun scheduleReminder(id: Int, epochMillis: Long, title: String, message: String) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, ReminderReceiver::class.java).apply {
                putExtra("title", title); putExtra("message", message); putExtra("id", id)
            }
            val pendingIntent = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            try {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMillis, pendingIntent)
            } catch (_: SecurityException) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMillis, pendingIntent)
                Toast.makeText(context, "Exakte Alarme bitte in Android erlauben.", Toast.LENGTH_LONG).show()
                if (android.os.Build.VERSION.SDK_INT >= 31) runCatching {
                    context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun cancelReminder(id: Int) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pendingIntent = PendingIntent.getBroadcast(context, id, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            alarmManager.cancel(pendingIntent)
        }

        @android.webkit.JavascriptInterface
        fun speak(message: String, volumePercent: Int, gender: String, voiceName: String, ratePercent: Int, pitchPercent: Int) = runOnUiThread {
            speakNative(message, volumePercent, gender, false, voiceName, ratePercent, pitchPercent)
        }

        @android.webkit.JavascriptInterface
        fun speakThenListen(message: String, volumePercent: Int, gender: String, voiceName: String, ratePercent: Int, pitchPercent: Int) = runOnUiThread {
            speakNative(message, volumePercent, gender, true, voiceName, ratePercent, pitchPercent)
        }

        @android.webkit.JavascriptInterface
        fun getGermanVoices(): String {
            val arr = org.json.JSONArray()
            textToSpeech?.voices?.filter { it.locale?.language == Locale.GERMAN.language }
                ?.sortedWith(compareByDescending<android.speech.tts.Voice> { it.quality }.thenBy { it.name })
                ?.forEach { v -> arr.put(org.json.JSONObject().put("name", v.name).put("locale", v.locale.toLanguageTag()).put("quality", v.quality).put("network", v.isNetworkConnectionRequired)) }
            return arr.toString()
        }

        @android.webkit.JavascriptInterface
        fun startListening() = runOnUiThread { startNativeListening() }

        @android.webkit.JavascriptInterface
        fun stopAssistant() = runOnUiThread {
            startListenRunnable?.let(mainHandler::removeCallbacks)
            startListenRunnable = null
            listenFallback?.let(mainHandler::removeCallbacks)
            listenFallback = null
            pendingNativeListen = false
            nativeListenRetries = 0
            disposeSpeechRecognizer()
            textToSpeech?.stop()
            sendAssistantStatus("Sprachassistent beendet.")
        }

        @android.webkit.JavascriptInterface
        fun estimateDriveMinutes(address: String): Int = estimateDriveMinutesForAddress(address)

        @android.webkit.JavascriptInterface
        fun requestLocationPermission() = runOnUiThread {
            val fine = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val coarse = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (!fine && !coarse) permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }

        @android.webkit.JavascriptInterface
        fun setOpenAiApiKey(apiKey: String) = runOnUiThread {
            runCatching { saveApiKeySecurely(apiKey) }
                .onFailure { Toast.makeText(context, "API-Schlüssel konnte nicht gespeichert werden.", Toast.LENGTH_LONG).show() }
        }

        @android.webkit.JavascriptInterface
        fun hasOpenAiApiKey(): Boolean = !loadApiKeySecurely().isNullOrBlank()

        @android.webkit.JavascriptInterface
        fun askOpenAI(message: String, previousResponseId: String?, model: String) {
            requestOpenAi(message.trim(), previousResponseId, model)
        }

        @android.webkit.JavascriptInterface
        fun stopSpeechAndListening() = runOnUiThread {
            listenFallback?.let(mainHandler::removeCallbacks)
            listenFallback = null
            startListenRunnable?.let(mainHandler::removeCallbacks)
            startListenRunnable = null
            disposeSpeechRecognizer()
            textToSpeech?.stop()
        }

        @android.webkit.JavascriptInterface
        fun printPdf(title: String) = runOnUiThread {
            val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
            val adapter = webView.createPrintDocumentAdapter(title.ifBlank { "Karsak Stundenzettel" })
            printManager.print(title.ifBlank { "Karsak Stundenzettel" }, adapter, PrintAttributes.Builder().build())
        }

        @android.webkit.JavascriptInterface
        fun isNativeApp(): Boolean = true
    }
}

-- FX72: Einmalig im Supabase SQL Editor ausführen
ALTER TABLE public.work_entries ADD COLUMN IF NOT EXISTS hourly_rate numeric(10,2);
ALTER TABLE public.work_entries ADD COLUMN IF NOT EXISTS review_reason text;

CREATE TABLE IF NOT EXISTS public.employee_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_name text NOT NULL,
  payment_date date NOT NULL,
  payment_type text NOT NULL,
  amount numeric(12,2) NOT NULL CHECK (amount >= 0),
  note text DEFAULT '',
  settlement_month text DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.employee_payments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS employee_payments_select_authenticated ON public.employee_payments;
DROP POLICY IF EXISTS employee_payments_insert_authenticated ON public.employee_payments;
DROP POLICY IF EXISTS employee_payments_update_authenticated ON public.employee_payments;
DROP POLICY IF EXISTS employee_payments_delete_authenticated ON public.employee_payments;
CREATE POLICY employee_payments_select_authenticated ON public.employee_payments FOR SELECT TO authenticated USING (true);
CREATE POLICY employee_payments_insert_authenticated ON public.employee_payments FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY employee_payments_update_authenticated ON public.employee_payments FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY employee_payments_delete_authenticated ON public.employee_payments FOR DELETE TO authenticated USING (true);

# Karsak Stundenzettel FIX1
Android-App für Arbeitszeiten und Baustellen mit Sprachassistent.

## Sprachablauf
Chef: Mitarbeiter -> Beginn -> Feierabend -> Baustelle/Projekt -> Tätigkeit -> Zusammenfassung -> Speichern.
Mitarbeiter: Beginn -> Feierabend -> Baustelle/Projekt -> Tätigkeit -> Zusammenfassung -> Speichern.

Die vorhandene Trennung bleibt erhalten: Mitarbeiter sehen ihre eigenen Zeiten; Stundenlöhne/Vorschüsse liegen im Chefbereich.

## APK bauen
Projekt in GitHub hochladen und unter Actions `Android APK bauen` starten. Das Ergebnis heißt `Karsak-Stundenzettel-APK`.


## FIX4
Datumserfassung nach Mitarbeiter, schnelle Satzanalyse und Monatsübersicht Januar–Dezember ergänzt.


## FIX5
Startseite mit vier getrennten Bereichen: Mitarbeiter, Sprachassistent, Zahlungen und Neuer Mitarbeiter. Mitarbeiteransicht enthält nur Mitarbeiter-Namen und Monatsübersicht.

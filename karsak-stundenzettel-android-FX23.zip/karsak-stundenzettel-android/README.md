# Karsak Stundenzettel FIX1
Android-App für Arbeitszeiten und Baustellen mit Sprachassistent.

## Sprachablauf
Chef: Mitarbeiter -> Beginn -> Feierabend -> Baustelle/Projekt -> Tätigkeit -> Zusammenfassung -> Speichern.
Mitarbeiter: Beginn -> Feierabend -> Baustelle/Projekt -> Tätigkeit -> Zusammenfassung -> Speichern.

Die vorhandene Trennung bleibt erhalten: Mitarbeiter sehen ihre eigenen Zeiten; Stundenlöhne/Vorschüsse liegen im Chefbereich.

## APK bauen
Projekt in GitHub hochladen und unter Actions `Android APK bauen` starten. Das Ergebnis heißt `Karsak-Stundenzettel-APK`.


## FIX4
Datumserfassung nach Mitarbeiter, schnelle Satzanalyse und Monatsübersicht Januar–Dezember ergänzt.


## FIX5
Startseite mit vier getrennten Bereichen: Mitarbeiter, Sprachassistent, Zahlungen und Neuer Mitarbeiter. Mitarbeiteransicht enthält nur Mitarbeiter-Namen und Monatsübersicht.

FX9: Sprachwahl per Zahl/Wort, Safe-Area für Bearbeiten/Speichern, Chef-Kacheln Stundenzettel/PDF.

## FX11
- Sprachassistent: Mitarbeiterauswahl per Name oder Nummer robuster.
- Akzeptiert z. B. „eins“, „1“, „Nummer eins“, „Mitarbeiter eins“, „zwei“, „2“ usw.
- Nummernauswahl wird direkt übernommen, ohne die Mitarbeiterfrage erneut zu stellen.


## FX16
- Stundenlohn wird bei jedem Zeiteintrag fest gespeichert (rateAtEntry).
- Spätere Änderungen des Mitarbeiter-Stundenlohns verändern alte Einsätze nicht mehr.
- Im Chefbereich kann der Lohnsatz eines einzelnen alten Einsatzes über 'Lohnsatz' korrigiert werden.
- PDF, Mitarbeiterübersicht und Baustellen-Lohnkosten verwenden den historischen Lohnsatz des jeweiligen Einsatzes.

FX17: Zuletzt gewählter Mitarbeiter bei manueller Zeiterfassung wird dauerhaft gemerkt.


## FX19
- Ein zentraler Startseitenpunkt „Zahlungen“.
- Zweite Auswahl: Mitarbeiter oder Projekt.
- Mitarbeiter: Vorschüsse/Lohnauszahlungen.
- Projekt: Kundenzahlungen, Sonderabmachungen/Nachträge sowie Material-/Rechnungszahlungen in einer Ansicht.
- Kundenzahlungen bleiben vom Gewinn getrennt; Projektausgaben fließen als Kosten ein.

## FX20
- Login neu: Chef zuerst, Mitarbeiter als direkter Auswahlpunkt; nach Mitarbeiterwahl erscheint sofort die Code-Eingabe.
- Chef-Startseite kompakter.
- Zahlungen: Mitarbeiter/Projekt als klare Unterauswahl.
- Mitarbeiterzahlungen: Mitarbeiterliste zuerst; Zahnrad für Bearbeiten oder Neuanlage.
- PDF: nur noch ein Startpunkt; danach Senden oder Speichern.
- PDF-Senden: native Android-Freigabe als PDF ergänzt.
- Projekte: Untermenü Auftrag anlegen / Aufträge.

## FX21 – Wasser/Glas-Design
- Komplett neues Chef-Dashboard im Wasser-/Glas-Look.
- Runde, transparente Wappen statt eckiger Kacheln.
- Dachdecker-Karsak-Wasserzeichen im Hintergrund.
- Kompakter Marken-Kopf mit Assistenten-Wappen.
- Bestehende Funktionen aus FX20 bleiben erhalten.


## FX22 FIX
- Aufbau direkt auf FX21.
- Compilerfehler der PDF-Freigabe korrigiert.
- Sechs kompakte transparente Rundbuttons.
- Ein zentrales Mitarbeiter-Zahnrad.
- Baustellengespräch-Aufnahme ergänzt.


## FX23
Release-Nummer nach der korrigierten FX22-Fassung auf FX23 weitergeführt.

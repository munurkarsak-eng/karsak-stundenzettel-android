plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.karsak.stundenzettel.mitarbeiterfx63"
    compileSdk = 35

    defaultConfig {
        val supabaseUrl = System.getenv("SUPABASE_URL") ?: ""
        val supabaseKey = System.getenv("SUPABASE_KEY") ?: ""
        buildConfigField("String", "SUPABASE_URL", "\"${supabaseUrl.replace("\"", "\\\"")}\"")
        buildConfigField("String", "SUPABASE_KEY", "\"${supabaseKey.replace("\"", "\\\"")}\"")
        applicationId = "de.karsak.stundenzettel.mitarbeiterfx63"
        minSdk = 26
        targetSdk = 35
        versionCode = 63
        versionName = "1.0.63"
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}


dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
}

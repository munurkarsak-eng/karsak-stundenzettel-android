-- Einmal im Supabase SQL Editor ausführen.
create table if not exists public.pending_hours (
  id text primary key,
  client_entry_id text not null,
  employee_id text,
  employee_name text,
  work_date text,
  start_time text,
  end_time text,
  site_id text,
  site_name text,
  note text,
  status text not null default 'pending',
  source text,
  app_version text,
  created_at timestamptz not null default now()
);

alter table public.pending_hours enable row level security;

drop policy if exists "Mitarbeiter duerfen Stunden senden" on public.pending_hours;
create policy "Mitarbeiter duerfen Stunden senden"
on public.pending_hours for insert
to anon
with check (true);

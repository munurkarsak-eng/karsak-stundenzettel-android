package de.karsak.stundenzettel.mitarbeiter
import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.RingtoneManager
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        val id = intent.getIntExtra("id", 1)
        val title = intent.getStringExtra("title") ?: "Karsak Terminplaner"
        val message = intent.getStringExtra("message") ?: "Erinnerung"
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "karsak_personal_reminders_v1"
        val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        manager.createNotificationChannel(NotificationChannel(channelId, "Erinnerungen", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Laute persönliche Erinnerungen mit Sprachausgabe"
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 700, 250, 700, 250, 900)
            setSound(sound, attrs)
            lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
        })

        val openIntent = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val contentIntent = PendingIntent.getActivity(context, id, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setSound(sound).setVibrate(longArrayOf(0, 700, 250, 700, 250, 900))
            .setAutoCancel(true).setContentIntent(contentIntent).build()
        if (android.os.Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) manager.notify(id, notification)

        // Kurz aufwecken, damit Alarm + TTS auch bei gesperrtem Bildschirm zuverlässig anlaufen.
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "KarsakTerminplaner:ReminderSpeech").apply { acquire(20_000L) }
        var tts: TextToSpeech? = null
        val finish = { runCatching { tts?.stop(); tts?.shutdown() }; if (wakeLock.isHeld) wakeLock.release(); pendingResult.finish() }
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status != TextToSpeech.SUCCESS) { finish(); return@TextToSpeech }
            val engine = tts ?: return@TextToSpeech
            engine.language = Locale.GERMANY
            engine.setSpeechRate(1.0f)
            engine.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit
                override fun onDone(utteranceId: String?) = finish()
                @Deprecated("Deprecated in Java") override fun onError(utteranceId: String?) = finish()
            })
            val spoken = if (message.startsWith("Erinnerung", true)) message else "Erinnerung. $message"
            engine.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, "karsak-reminder-$id")
        }
    }
}
